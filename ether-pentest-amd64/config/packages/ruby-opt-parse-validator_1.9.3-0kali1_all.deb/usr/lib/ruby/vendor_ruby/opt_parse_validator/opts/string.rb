# frozen_string_literal: true

module OptParseValidator
  # Alias of OptBase
  # Used for convenience
  class OptString < OptBase
  end
end
