# frozen_string_literal: true

module OptParseValidator
  # Implementation of the Proxy Option
  class OptProxy < OptURI
  end
end
