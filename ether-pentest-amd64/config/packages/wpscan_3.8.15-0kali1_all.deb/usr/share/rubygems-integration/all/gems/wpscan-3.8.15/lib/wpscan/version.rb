# frozen_string_literal: true

# Version
module WPScan
  VERSION = '3.8.15'
end
