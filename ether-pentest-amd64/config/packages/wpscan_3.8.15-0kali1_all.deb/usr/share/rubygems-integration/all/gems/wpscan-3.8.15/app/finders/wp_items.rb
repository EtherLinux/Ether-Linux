# frozen_string_literal: true

require_relative 'wp_items/urls_in_page'
