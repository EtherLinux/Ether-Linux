__author__ = "Alban Diquet"
__version__ = "4.0.0"
