# Dummy module for backward compatibility
from visvis.utils.pypoints import *  # noqa
