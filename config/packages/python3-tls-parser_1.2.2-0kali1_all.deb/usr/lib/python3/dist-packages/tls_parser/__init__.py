from __future__ import absolute_import
from __future__ import print_function

__version__ = '1.2.2'
__author__ = 'Alban Diquet'
__email__ = 'nabla.c0d3@gmail.com'

# A very useful page for working on this module:
# http://blog.fourthbit.com/2014/12/23/traffic-analysis-of-an-ssl-slash-tls-session
