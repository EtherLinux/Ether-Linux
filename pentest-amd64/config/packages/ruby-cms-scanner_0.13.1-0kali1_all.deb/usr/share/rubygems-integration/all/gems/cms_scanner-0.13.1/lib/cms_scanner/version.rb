# frozen_string_literal: true

# Version
module CMSScanner
  VERSION = '0.13.1'
end
