# frozen_string_literal: true

module CMSScanner
  module Formatter
    # Because Reason https://github.com/wpscanteam/CMSScanner/issues/56
    class CliNoColor < CliNoColour
    end
  end
end
