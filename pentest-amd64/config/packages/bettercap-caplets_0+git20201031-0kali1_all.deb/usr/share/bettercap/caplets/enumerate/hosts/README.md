# enumerate.hosts

A simple module that lets you enumerate individual hosts.

Example:

![screenshot from 2018-07-27 00-37-40](https://user-images.githubusercontent.com/29265684/43269395-1cc4d330-9136-11e8-941b-f0d9fcb6e254.png)
