# enumerate.events

A simple module that lets you enumerate events.

Example:

`enumerate.events.regexp GET|POST|HEAD|PUT|DELETE|CONNECT|OPTIONS|TRACE|PATCH|=>|Form:`

<sup>(this command will print all HTTP events; regexp must be written as in `new RegExp()`)</sup>

![screenshot from 2018-07-27 21-48-20](https://user-images.githubusercontent.com/29265684/43319311-97526282-91e7-11e8-854e-c209ba60b732.png)
