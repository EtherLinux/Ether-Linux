#!/usr/bin/python3

import sys
print('Dummy!')
sys.exit(1)
